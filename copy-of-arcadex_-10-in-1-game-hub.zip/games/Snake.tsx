import React, { useState, useEffect, useCallback, useRef } from 'react';
import { ArrowLeft, Play, Trophy } from 'lucide-react';

const COLS = 20;
const ROWS = 20;
const SPEED = 100;

type Point = { x: number, y: number };

export default function Snake({ onBack }: { onBack: () => void }) {
  const [snake, setSnake] = useState<Point[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<Point>({ x: 5, y: 5 });
  const [dir, setDir] = useState<Point>({ x: 0, y: -1 });
  const [gameOver, setGameOver] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  
  // Refs for loop
  const dirRef = useRef(dir);
  const gameLoopRef = useRef<number>(0);

  const generateFood = () => {
    return {
      x: Math.floor(Math.random() * COLS),
      y: Math.floor(Math.random() * ROWS)
    };
  };

  const reset = () => {
    setSnake([{ x: 10, y: 10 }]);
    setFood(generateFood());
    setDir({ x: 0, y: -1 });
    dirRef.current = { x: 0, y: -1 };
    setGameOver(false);
    setPlaying(true);
    setScore(0);
  };

  const moveSnake = useCallback(() => {
    if (!playing || gameOver) return;

    setSnake(prev => {
      const head = { ...prev[0] };
      head.x += dirRef.current.x;
      head.y += dirRef.current.y;

      // Collision Walls
      if (head.x < 0 || head.x >= COLS || head.y < 0 || head.y >= ROWS) {
        setGameOver(true);
        return prev;
      }

      // Collision Self
      if (prev.some(s => s.x === head.x && s.y === head.y)) {
        setGameOver(true);
        return prev;
      }

      const newSnake = [head, ...prev];

      // Eat Food
      if (head.x === food.x && head.y === food.y) {
        setScore(s => s + 1);
        setFood(generateFood());
      } else {
        newSnake.pop();
      }

      return newSnake;
    });
  }, [food, playing, gameOver]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp': if (dirRef.current.y === 0) dirRef.current = { x: 0, y: -1 }; break;
        case 'ArrowDown': if (dirRef.current.y === 0) dirRef.current = { x: 0, y: 1 }; break;
        case 'ArrowLeft': if (dirRef.current.x === 0) dirRef.current = { x: -1, y: 0 }; break;
        case 'ArrowRight': if (dirRef.current.x === 0) dirRef.current = { x: 1, y: 0 }; break;
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    if (playing && !gameOver) {
      const interval = setInterval(moveSnake, SPEED);
      return () => clearInterval(interval);
    }
  }, [playing, gameOver, moveSnake]);

  return (
    <div className="flex flex-col items-center justify-center h-full p-4 relative">
       <button onClick={onBack} className="absolute top-4 left-4 text-white hover:text-green-400">
        <ArrowLeft />
      </button>

      <div className="mb-4 text-white flex items-center gap-4 text-xl font-bold">
        <Trophy className="text-yellow-400" /> {score}
      </div>

      <div className="relative bg-slate-800 border-4 border-slate-700 rounded-lg overflow-hidden shadow-2xl">
        <div 
          className="grid bg-black/50" 
          style={{ 
            gridTemplateColumns: `repeat(${COLS}, 20px)`, 
            gridTemplateRows: `repeat(${ROWS}, 20px)` 
          }}
        >
          {Array(ROWS * COLS).fill(0).map((_, i) => {
            const x = i % COLS;
            const y = Math.floor(i / COLS);
            const isSnake = snake.some(s => s.x === x && s.y === y);
            const isFood = food.x === x && food.y === y;
            const isHead = snake[0].x === x && snake[0].y === y;
            
            return (
              <div key={i} className="w-full h-full flex items-center justify-center">
                {isSnake && <div className={`w-[18px] h-[18px] ${isHead ? 'bg-green-400 rounded-sm' : 'bg-green-600 rounded-sm'}`} />}
                {isFood && <div className="w-[14px] h-[14px] bg-red-500 rounded-full animate-pulse" />}
              </div>
            );
          })}
        </div>

        {(!playing || gameOver) && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/70 flex-col">
            <h2 className={`text-4xl font-bold mb-4 ${gameOver ? 'text-red-500' : 'text-green-500'}`}>
              {gameOver ? 'GAME OVER' : 'SNAKE'}
            </h2>
            <button onClick={reset} className="bg-white text-black px-6 py-2 rounded-full font-bold flex items-center gap-2 hover:bg-gray-200">
              <Play size={20} /> {gameOver ? 'RETRY' : 'START'}
            </button>
          </div>
        )}
      </div>

      {/* Mobile Controls */}
      <div className="grid grid-cols-3 gap-2 mt-8 md:hidden">
        <div />
        <button className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center active:bg-slate-600" onPointerDown={() => {if(dirRef.current.y===0) dirRef.current={x:0, y:-1}}}>⬆️</button>
        <div />
        <button className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center active:bg-slate-600" onPointerDown={() => {if(dirRef.current.x===0) dirRef.current={x:-1, y:0}}}>⬅️</button>
        <button className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center active:bg-slate-600" onPointerDown={() => {if(dirRef.current.y===0) dirRef.current={x:0, y:1}}}>⬇️</button>
        <button className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center active:bg-slate-600" onPointerDown={() => {if(dirRef.current.x===0) dirRef.current={x:1, y:0}}}>➡️</button>
      </div>
    </div>
  );
}