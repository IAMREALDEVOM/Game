import React, { useState, useEffect, useCallback } from 'react';
import { ArrowLeft, Timer, Brain } from 'lucide-react';

const SHAPES = ['Square', 'Circle', 'Triangle'];
const COLORS = [
  { name: 'Red', hex: 'bg-red-500' },
  { name: 'Blue', hex: 'bg-blue-500' },
  { name: 'Green', hex: 'bg-green-500' },
  { name: 'Yellow', hex: 'bg-yellow-500' }
];

interface Option {
  shape: string;
  color: typeof COLORS[0];
  id: string;
}

export default function BrainSpeed({ onBack }: { onBack: () => void }) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [target, setTarget] = useState<Option | null>(null);
  const [options, setOptions] = useState<Option[]>([]);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  const generateRound = useCallback(() => {
    const newOptions: Option[] = [];
    for (let i = 0; i < 4; i++) {
      newOptions.push({
        shape: SHAPES[Math.floor(Math.random() * SHAPES.length)],
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        id: Math.random().toString()
      });
    }
    setOptions(newOptions);
    setTarget(newOptions[Math.floor(Math.random() * newOptions.length)]);
  }, []);

  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setIsPlaying(true);
    generateRound();
  };

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          setIsPlaying(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  const handleOptionClick = (option: Option) => {
    if (!isPlaying) return;
    if (option.id === target?.id) {
      setScore(s => s + 10);
      setFeedback('correct');
      // Bonus time every 5 correct
      if ((score + 10) % 50 === 0) setTimeLeft(t => Math.min(t + 5, 30));
    } else {
      setScore(s => Math.max(0, s - 5));
      setFeedback('wrong');
      setTimeLeft(t => Math.max(0, t - 2));
    }
    setTimeout(() => setFeedback(null), 200);
    generateRound();
  };

  const renderShape = (shape: string, colorClass: string) => {
    const base = `w-16 h-16 ${colorClass} transition-transform`;
    if (shape === 'Square') return <div className={`${base} rounded-md`} />;
    if (shape === 'Circle') return <div className={`${base} rounded-full`} />;
    if (shape === 'Triangle') return <div className={`w-0 h-0 border-l-[32px] border-l-transparent border-r-[32px] border-r-transparent border-b-[64px] border-b-${colorClass.split('-')[1]}-500`} />;
    return null;
  };

  return (
    <div className="flex flex-col h-full items-center justify-center p-4 relative">
      <button onClick={onBack} className="absolute top-4 left-4 text-white hover:text-rose-400 flex items-center gap-2">
        <ArrowLeft /> Back
      </button>

      <div className="max-w-md w-full bg-slate-800 rounded-2xl p-6 shadow-2xl border border-slate-700">
        <div className="flex justify-between items-center mb-6 text-white">
          <div className="flex items-center gap-2 text-rose-400 font-bold">
            <Brain /> {score} pts
          </div>
          <div className={`flex items-center gap-2 font-mono text-xl ${timeLeft < 5 ? 'text-red-500 animate-pulse' : 'text-slate-300'}`}>
            <Timer /> {timeLeft}s
          </div>
        </div>

        {!isPlaying && timeLeft === 0 ? (
           <div className="text-center py-10">
             <h2 className="text-3xl font-bold text-white mb-2">Time's Up!</h2>
             <p className="text-xl text-slate-400 mb-6">Final Score: {score}</p>
             <button onClick={startGame} className="bg-rose-500 hover:bg-rose-600 text-white px-8 py-3 rounded-full font-bold transition">
               Play Again
             </button>
           </div>
        ) : !isPlaying ? (
          <div className="text-center py-10">
            <h2 className="text-2xl font-bold text-white mb-4">Brain Speed Test</h2>
            <p className="text-slate-400 mb-8">Tap the card that matches the instruction above.</p>
            <button onClick={startGame} className="bg-rose-500 hover:bg-rose-600 text-white px-8 py-3 rounded-full font-bold transition">
              Start
            </button>
          </div>
        ) : (
          <>
            <div className="text-center mb-8">
              <p className="text-slate-400 text-sm mb-2 uppercase tracking-wider">Tap this:</p>
              <div className="flex items-center justify-center gap-2 text-2xl font-bold text-white">
                 <span className={`${target?.color.hex.replace('bg-', 'text-')} capitalize`}>{target?.color.name}</span>
                 <span>{target?.shape}</span>
              </div>
            </div>

            <div className={`grid grid-cols-2 gap-4 transition-colors duration-200 rounded-xl p-2 ${feedback === 'correct' ? 'bg-green-500/20' : feedback === 'wrong' ? 'bg-red-500/20' : ''}`}>
              {options.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => handleOptionClick(opt)}
                  className="h-32 bg-slate-700 rounded-xl flex items-center justify-center hover:bg-slate-600 active:scale-95 transition-all"
                >
                  {renderShape(opt.shape, opt.color.hex)}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}