import React, { useRef, useEffect, useState } from 'react';
import { ArrowLeft, Swords } from 'lucide-react';

interface Enemy {
  id: number;
  side: 'left' | 'right';
  x: number;
  speed: number;
  type: 'normal' | 'fast';
}

export default function StickmanFight({ onBack }: { onBack: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  
  const gameState = useRef({
    player: { state: 'idle' as 'idle' | 'attack_left' | 'attack_right', timer: 0 },
    enemies: [] as Enemy[],
    lastSpawn: 0,
    difficulty: 1,
    animationId: 0
  });

  const CENTER_X = 400;
  const PLAYER_Y = 250;

  const resetGame = () => {
    gameState.current.enemies = [];
    gameState.current.difficulty = 1;
    gameState.current.player.state = 'idle';
    setScore(0);
    setGameOver(false);
    setIsPlaying(true);
  };

  const drawStickman = (ctx: CanvasRenderingContext2D, x: number, y: number, color: string, pose: 'idle' | 'attack' | 'run') => {
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // Head
    ctx.beginPath();
    ctx.arc(x, y - 20, 10, 0, Math.PI * 2);
    ctx.stroke();

    // Body
    ctx.beginPath();
    ctx.moveTo(x, y - 10);
    ctx.lineTo(x, y + 20);
    ctx.stroke();

    // Legs
    ctx.beginPath();
    ctx.moveTo(x, y + 20);
    if (pose === 'idle') {
      ctx.lineTo(x - 10, y + 40);
      ctx.moveTo(x, y + 20);
      ctx.lineTo(x + 10, y + 40);
    } else if (pose === 'run') {
       ctx.lineTo(x - 15, y + 35);
       ctx.moveTo(x, y + 20);
       ctx.lineTo(x + 15, y + 35);
    } else { // Attack kick
       ctx.lineTo(x - 10, y + 40);
       ctx.moveTo(x, y + 20);
       ctx.lineTo(x + 25, y + 10); // High kick
    }
    ctx.stroke();

    // Arms
    ctx.beginPath();
    ctx.moveTo(x, y - 5);
    if (pose === 'attack') {
        ctx.lineTo(x + 20, y - 5); // Punch
    } else {
        ctx.lineTo(x - 10, y + 10);
        ctx.moveTo(x, y - 5);
        ctx.lineTo(x + 10, y + 10);
    }
    ctx.stroke();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const update = (timestamp: number) => {
      if (!isPlaying || gameOver) return;

      const state = gameState.current;
      
      // Spawn Logic
      if (timestamp - state.lastSpawn > 1500 / state.difficulty) {
        state.lastSpawn = timestamp;
        state.difficulty += 0.05;
        const side = Math.random() > 0.5 ? 'left' : 'right';
        state.enemies.push({
          id: Math.random(),
          side,
          x: side === 'left' ? -20 : 820,
          speed: (2 + Math.random() * 2) * (state.difficulty * 0.5),
          type: Math.random() > 0.8 ? 'fast' : 'normal'
        });
      }

      // Player Animation Reset
      if (state.player.state !== 'idle') {
        state.player.timer--;
        if (state.player.timer <= 0) state.player.state = 'idle';
      }

      // Update Enemies
      for (let i = state.enemies.length - 1; i >= 0; i--) {
        const enemy = state.enemies[i];
        if (enemy.side === 'left') enemy.x += enemy.speed;
        else enemy.x -= enemy.speed;

        // Collision/Attack Check
        const dist = Math.abs(enemy.x - CENTER_X);
        
        // Player Hit Enemy
        if (dist < 60 && state.player.state !== 'idle') {
          if ((state.player.state === 'attack_left' && enemy.side === 'left') ||
              (state.player.state === 'attack_right' && enemy.side === 'right')) {
            state.enemies.splice(i, 1);
            setScore(s => s + 1);
            continue;
          }
        }

        // Enemy Hit Player
        if (dist < 20) {
          setGameOver(true);
        }
      }

      // Draw
      ctx.clearRect(0, 0, 800, 400);

      // Floor
      ctx.fillStyle = '#334155';
      ctx.fillRect(0, PLAYER_Y + 40, 800, 2);

      // Player
      ctx.save();
      if (state.player.state === 'attack_left') {
        ctx.translate(CENTER_X, PLAYER_Y);
        ctx.scale(-1, 1); // Flip for left attack
        ctx.translate(-CENTER_X, -PLAYER_Y);
      }
      drawStickman(ctx, CENTER_X, PLAYER_Y, '#fff', state.player.state === 'idle' ? 'idle' : 'attack');
      ctx.restore();

      // Enemies
      state.enemies.forEach(enemy => {
        ctx.save();
        if (enemy.side === 'right') {
           ctx.translate(enemy.x, PLAYER_Y);
           ctx.scale(-1, 1);
           ctx.translate(-enemy.x, -PLAYER_Y);
        }
        drawStickman(ctx, enemy.x, PLAYER_Y, enemy.type === 'fast' ? '#ef4444' : '#94a3b8', 'run');
        ctx.restore();
      });

      // Range Indicators
      ctx.strokeStyle = '#ffffff20';
      ctx.beginPath();
      ctx.moveTo(CENTER_X - 60, PLAYER_Y + 45);
      ctx.lineTo(CENTER_X - 60, PLAYER_Y + 55);
      ctx.moveTo(CENTER_X + 60, PLAYER_Y + 45);
      ctx.lineTo(CENTER_X + 60, PLAYER_Y + 55);
      ctx.stroke();

      gameState.current.animationId = requestAnimationFrame(update);
    };

    if (isPlaying && !gameOver) {
      gameState.current.animationId = requestAnimationFrame(update);
    }

    return () => cancelAnimationFrame(gameState.current.animationId);
  }, [isPlaying, gameOver]);

  // Controls
  const attack = (side: 'left' | 'right') => {
    if (gameOver) return;
    gameState.current.player.state = side === 'left' ? 'attack_left' : 'attack_right';
    gameState.current.player.timer = 10; // 10 frames of attack
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a') attack('left');
      if (e.key === 'ArrowRight' || e.key === 'd') attack('right');
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [gameOver]);

  return (
    <div className="flex flex-col items-center justify-center h-full relative select-none">
      <div className="absolute top-4 left-4 z-10">
        <button onClick={onBack} className="flex items-center gap-2 text-white hover:text-red-400 transition">
          <ArrowLeft /> Back
        </button>
      </div>

      <div className="relative">
        <canvas ref={canvasRef} width={800} height={400} className="bg-slate-900 rounded-xl shadow-2xl" />
        
        <div className="absolute top-4 right-4 text-white font-pixel text-xl">
           Kills: {score}
        </div>

        {!isPlaying && !gameOver && (
           <div className="absolute inset-0 bg-black/60 flex items-center justify-center flex-col text-white">
             <Swords size={48} className="mb-4 text-red-500"/>
             <h1 className="text-4xl font-bold mb-2">STICKMAN ARENA</h1>
             <p className="mb-6 text-slate-300">Left/Right Arrow to Attack</p>
             <button onClick={resetGame} className="bg-red-600 hover:bg-red-700 px-8 py-3 rounded-full font-bold">FIGHT</button>
           </div>
        )}
        
        {gameOver && (
           <div className="absolute inset-0 bg-red-900/80 flex items-center justify-center flex-col text-white">
             <h1 className="text-5xl font-bold mb-4">YOU DIED</h1>
             <p className="text-xl mb-6">Total Kills: {score}</p>
             <button onClick={resetGame} className="bg-white text-red-900 px-8 py-3 rounded-full font-bold">TRY AGAIN</button>
           </div>
        )}

        {/* Mobile Controls Overlay */}
        <div className="absolute inset-x-0 bottom-0 h-1/2 flex">
           <div className="w-1/2 h-full active:bg-white/5 transition-colors" onPointerDown={() => attack('left')} />
           <div className="w-1/2 h-full active:bg-white/5 transition-colors" onPointerDown={() => attack('right')} />
        </div>
      </div>
    </div>
  );
}