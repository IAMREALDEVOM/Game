import React, { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCw } from 'lucide-react';

const WIDTH = 8;
const CANDY_COLORS = [
  'bg-red-500',
  'bg-yellow-500',
  'bg-orange-500',
  'bg-purple-500',
  'bg-green-500',
  'bg-blue-500'
];

export default function Match3({ onBack }: { onBack: () => void }) {
  const [board, setBoard] = useState<string[]>([]);
  const [dragged, setDragged] = useState<number | null>(null);
  const [score, setScore] = useState(0);

  const createBoard = () => {
    const randomBoard = [];
    for (let i = 0; i < WIDTH * WIDTH; i++) {
      randomBoard.push(CANDY_COLORS[Math.floor(Math.random() * CANDY_COLORS.length)]);
    }
    setBoard(randomBoard);
    setScore(0);
  };

  useEffect(() => {
    createBoard();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      checkForMatches();
    }, 100);
    return () => clearInterval(timer);
  }, [board]);

  const checkForMatches = () => {
    // Check rows and columns of 3
    const newBoard = [...board];
    let isMatch = false;

    // Row check
    for (let i = 0; i < 64; i++) {
      // Row
      if (i % WIDTH < WIDTH - 2) {
        if (newBoard[i] && newBoard[i] === newBoard[i+1] && newBoard[i] === newBoard[i+2]) {
          newBoard[i] = '';
          newBoard[i+1] = '';
          newBoard[i+2] = '';
          isMatch = true;
          setScore(s => s + 3);
        }
      }
      // Col
      if (i < 64 - WIDTH * 2) {
         if (newBoard[i] && newBoard[i] === newBoard[i+WIDTH] && newBoard[i] === newBoard[i+WIDTH*2]) {
          newBoard[i] = '';
          newBoard[i+WIDTH] = '';
          newBoard[i+WIDTH*2] = '';
          isMatch = true;
          setScore(s => s + 3);
         }
      }
    }

    if (isMatch) {
       setBoard(newBoard);
       setTimeout(moveDown, 100);
    }
  };

  const moveDown = () => {
    const newBoard = [...board];
    for (let i = 0; i <= 55; i++) {
      const firstRow = [0,1,2,3,4,5,6,7];
      const isFirstRow = firstRow.includes(i);
      
      if (isFirstRow && newBoard[i] === '') {
        newBoard[i] = CANDY_COLORS[Math.floor(Math.random() * CANDY_COLORS.length)];
      }

      if (newBoard[i + WIDTH] === '') {
        newBoard[i + WIDTH] = newBoard[i];
        newBoard[i] = '';
      }
    }
    setBoard(newBoard);
  };

  const dragStart = (e: React.DragEvent, id: number) => {
    setDragged(id);
  };

  const dragDrop = (e: React.DragEvent, targetId: number) => {
    if (dragged === null) return;
    const newBoard = [...board];
    const originColor = newBoard[dragged];
    const targetColor = newBoard[targetId];

    // Simple adjacent check
    if ([dragged-1, dragged+1, dragged-WIDTH, dragged+WIDTH].includes(targetId)) {
       newBoard[targetId] = originColor;
       newBoard[dragged] = targetColor;
       setBoard(newBoard);
    }
    setDragged(null);
  };

  return (
    <div className="flex flex-col items-center justify-center h-full p-4">
      <div className="flex justify-between w-full max-w-md mb-4 items-center">
        <button onClick={onBack} className="text-white hover:text-purple-400">
            <ArrowLeft />
        </button>
        <div className="text-2xl font-bold text-white">Score: {score}</div>
        <button onClick={createBoard} className="text-white hover:text-purple-400">
            <RefreshCw />
        </button>
      </div>

      <div className="w-[320px] h-[320px] bg-slate-800 rounded-lg flex flex-wrap shadow-2xl border-4 border-slate-700">
        {board.map((color, index) => (
          <div
            key={index}
            className="w-10 h-10 flex items-center justify-center"
            draggable
            onDragStart={(e) => dragStart(e, index)}
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => dragDrop(e, index)}
          >
            {color && (
              <div 
                className={`w-8 h-8 rounded-full ${color} cursor-pointer hover:scale-110 transition-transform shadow-md`} 
                style={{ backgroundImage: 'radial-gradient(circle at 30% 30%, rgba(255,255,255,0.4), transparent)' }}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}