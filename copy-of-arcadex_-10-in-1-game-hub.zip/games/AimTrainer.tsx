import React, { useState, useEffect } from 'react';
import { ArrowLeft, Crosshair, MousePointer2 } from 'lucide-react';

export default function AimTrainer({ onBack }: { onBack: () => void }) {
  const [targets, setTargets] = useState<{id: number, x: number, y: number, createdAt: number}[]>([]);
  const [score, setScore] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30);

  const spawnTarget = () => {
    const id = Date.now();
    const x = Math.random() * 80 + 10; // %
    const y = Math.random() * 80 + 10; // %
    setTargets(prev => [...prev, { id, x, y, createdAt: Date.now() }]);
  };

  const clickTarget = (id: number) => {
    setScore(s => s + 1);
    setTargets(prev => prev.filter(t => t.id !== id));
    spawnTarget();
  };

  const startGame = () => {
    setScore(0);
    setTimeLeft(30);
    setTargets([]);
    setPlaying(true);
    spawnTarget();
  };

  useEffect(() => {
    if (!playing) return;
    const timer = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 1) {
          setPlaying(false);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [playing]);

  return (
    <div className="flex flex-col items-center justify-center h-full relative overflow-hidden cursor-crosshair">
       <button onClick={onBack} className="absolute top-4 left-4 text-white hover:text-cyan-400 z-50 cursor-pointer">
        <ArrowLeft />
      </button>

      {!playing ? (
        <div className="text-center z-10">
          <h1 className="text-4xl font-bold text-cyan-400 mb-4">AIM TRAINER</h1>
          <p className="text-white mb-8 text-xl">Score: {score}</p>
          <button onClick={startGame} className="bg-cyan-600 hover:bg-cyan-500 text-white px-8 py-3 rounded-full font-bold text-xl flex items-center justify-center gap-2 mx-auto">
             <Crosshair /> START
          </button>
        </div>
      ) : (
        <>
          <div className="absolute top-4 right-4 text-white text-2xl font-mono font-bold">
            Time: {timeLeft} | Score: {score}
          </div>
          
          <div className="w-full h-full relative">
            {targets.map(t => (
              <button
                key={t.id}
                onMouseDown={() => clickTarget(t.id)}
                className="absolute w-12 h-12 rounded-full bg-cyan-500 border-4 border-white shadow-lg hover:scale-90 active:scale-75 transition-transform"
                style={{ left: `${t.x}%`, top: `${t.y}%`, transform: 'translate(-50%, -50%)' }}
              >
                <div className="w-full h-full rounded-full border-2 border-cyan-800 opacity-50" />
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}