import React, { useState, useEffect } from 'react';
import { ArrowLeft, DoorOpen, Footprints, Flag } from 'lucide-react';

const SIZE = 10;

// 0: Floor, 1: Wall, 2: Start, 3: End, 4: Trap Portal, 5: Good Portal
const LEVEL = [
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
  [1, 2, 0, 0, 1, 0, 0, 0, 5, 1],
  [1, 1, 1, 0, 1, 0, 1, 1, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 1, 0, 1],
  [1, 0, 1, 1, 1, 1, 0, 1, 0, 1],
  [1, 0, 1, 4, 0, 1, 0, 0, 0, 1],
  [1, 0, 0, 0, 0, 0, 0, 1, 0, 1],
  [1, 1, 1, 1, 1, 1, 0, 1, 0, 1],
  [1, 3, 0, 0, 0, 0, 0, 1, 0, 1],
  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
];

export default function PortalEscape({ onBack }: { onBack: () => void }) {
  const [pos, setPos] = useState({ x: 1, y: 1 });
  const [msg, setMsg] = useState('');

  const handleMove = (dx: number, dy: number) => {
    const nx = pos.x + dx;
    const ny = pos.y + dy;
    const tile = LEVEL[ny][nx];

    if (tile === 1) return; // Wall

    if (tile === 3) {
      setMsg('You Escaped! 🎉');
      setPos({ x: 1, y: 1 });
    } else if (tile === 4) {
      setMsg('It was a TRAP! Back to start.');
      setPos({ x: 1, y: 1 });
    } else if (tile === 5) {
      setMsg('Teleported!');
      setPos({ x: 1, y: 8 }); // Teleport close to exit
    } else {
      setMsg('');
      setPos({ x: nx, y: ny });
    }
  };

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp') handleMove(0, -1);
      if (e.key === 'ArrowDown') handleMove(0, 1);
      if (e.key === 'ArrowLeft') handleMove(-1, 0);
      if (e.key === 'ArrowRight') handleMove(1, 0);
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [pos]);

  return (
    <div className="flex flex-col items-center justify-center h-full">
       <button onClick={onBack} className="absolute top-4 left-4 text-white hover:text-blue-400">
        <ArrowLeft />
      </button>

      <h1 className="text-2xl font-bold text-indigo-400 mb-4">PORTAL ESCAPE</h1>
      <p className="h-8 text-white mb-4">{msg}</p>

      <div className="grid gap-1 bg-indigo-900 p-2 rounded-lg shadow-2xl" style={{ gridTemplateColumns: `repeat(${SIZE}, 40px)` }}>
        {LEVEL.map((row, y) => row.map((tile, x) => {
          const isPlayer = pos.x === x && pos.y === y;
          return (
            <div key={`${x}-${y}`} className={`w-10 h-10 flex items-center justify-center rounded-sm ${tile === 1 ? 'bg-indigo-950' : 'bg-indigo-800'}`}>
              {tile === 3 && <Flag className="text-green-400" />}
              {(tile === 4 || tile === 5) && <DoorOpen className={`${tile === 4 ? 'text-red-500' : 'text-blue-400'}`} />}
              {isPlayer && <div className="w-6 h-6 bg-white rounded-full shadow-lg flex items-center justify-center"><Footprints size={14} className="text-black"/></div>}
            </div>
          );
        }))}
      </div>
      <p className="mt-4 text-slate-400 text-sm">Use Arrow Keys</p>
    </div>
  );
}