import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, Trash2, TreeDeciduous, Home, Waves, Car } from 'lucide-react';

type TileType = 'grass' | 'road' | 'house' | 'tree' | 'water';

const GRID_SIZE = 10;

const TILES: Record<TileType, { icon: string, color: string, bg: string }> = {
  grass: { icon: '', color: '', bg: 'bg-emerald-800' },
  road: { icon: '🛣️', color: 'text-slate-400', bg: 'bg-slate-700' },
  house: { icon: '🏠', color: 'text-orange-400', bg: 'bg-emerald-800' },
  tree: { icon: '🌲', color: 'text-green-400', bg: 'bg-emerald-800' },
  water: { icon: '🌊', color: 'text-blue-400', bg: 'bg-blue-600' }
};

export default function CityBuilder({ onBack }: { onBack: () => void }) {
  const [grid, setGrid] = useState<TileType[]>(Array(GRID_SIZE * GRID_SIZE).fill('grass'));
  const [selectedTool, setSelectedTool] = useState<TileType>('house');
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const savedCity = localStorage.getItem('mini-city-save');
    if (savedCity) {
      setGrid(JSON.parse(savedCity));
    }
  }, []);

  const handleTileClick = (index: number) => {
    const newGrid = [...grid];
    newGrid[index] = selectedTool;
    setGrid(newGrid);
    setSaved(false);
  };

  const saveCity = () => {
    localStorage.setItem('mini-city-save', JSON.stringify(grid));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const clearCity = () => {
    if (confirm('Clear your city?')) {
      setGrid(Array(GRID_SIZE * GRID_SIZE).fill('grass'));
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full p-4">
      <div className="w-full max-w-4xl flex items-center justify-between mb-6">
        <button onClick={onBack} className="text-white hover:text-green-400 flex items-center gap-2">
          <ArrowLeft /> Exit
        </button>
        <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-600">
          MINI CITY
        </h1>
        <div className="flex gap-2">
           <button onClick={clearCity} className="p-2 text-red-400 hover:bg-red-400/20 rounded-lg" title="Clear">
             <Trash2 size={20} />
           </button>
           <button onClick={saveCity} className={`p-2 rounded-lg flex items-center gap-2 ${saved ? 'text-green-400' : 'text-blue-400 hover:bg-blue-400/20'}`}>
             <Save size={20} /> {saved ? 'Saved!' : 'Save'}
           </button>
        </div>
      </div>

      <div className="flex gap-8 flex-col md:flex-row items-start">
        {/* Toolbar */}
        <div className="flex md:flex-col gap-2 bg-slate-800 p-2 rounded-xl shadow-xl">
          {(Object.keys(TILES) as TileType[]).map((type) => (
             <button
               key={type}
               onClick={() => setSelectedTool(type)}
               className={`w-12 h-12 rounded-lg flex items-center justify-center text-2xl transition-all ${selectedTool === type ? 'bg-white/20 ring-2 ring-green-400 scale-110' : 'hover:bg-white/5'}`}
               title={type}
             >
               {type === 'grass' ? <div className="w-4 h-4 bg-emerald-600 rounded-sm" /> : TILES[type].icon}
             </button>
          ))}
        </div>

        {/* Grid */}
        <div 
          className="grid gap-1 bg-slate-900 p-2 rounded-lg shadow-2xl border border-slate-800"
          style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))` }}
        >
          {grid.map((tile, i) => (
            <div
              key={i}
              onClick={() => handleTileClick(i)}
              className={`w-10 h-10 sm:w-14 sm:h-14 md:w-16 md:h-16 flex items-center justify-center text-2xl sm:text-3xl cursor-pointer hover:brightness-110 active:scale-95 transition-transform ${TILES[tile].bg}`}
            >
              <span className={TILES[tile].color}>{TILES[tile].icon}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}