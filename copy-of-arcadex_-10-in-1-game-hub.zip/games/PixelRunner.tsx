import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ArrowLeft, Play, RefreshCw, Trophy } from 'lucide-react';

interface Obstacle {
  x: number;
  y: number;
  w: number;
  h: number;
  type: 'ground' | 'air';
}

const GRAVITY = 0.6;
const JUMP_FORCE = -12;
const SPEED_INITIAL = 5;

export default function PixelRunner({ onBack }: { onBack: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  // Game state refs (for loop)
  const gameState = useRef({
    player: { x: 50, y: 0, w: 30, h: 30, dy: 0, grounded: true },
    obstacles: [] as Obstacle[],
    speed: SPEED_INITIAL,
    frame: 0
  });

  const jump = useCallback(() => {
    if (gameState.current.player.grounded) {
      gameState.current.player.dy = JUMP_FORCE;
      gameState.current.player.grounded = false;
    }
  }, []);

  const resetGame = () => {
    gameState.current = {
      player: { x: 50, y: 200, w: 30, h: 30, dy: 0, grounded: true },
      obstacles: [],
      speed: SPEED_INITIAL,
      frame: 0
    };
    setScore(0);
    setGameOver(false);
    setIsPlaying(true);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;

    const update = () => {
      if (!isPlaying || gameOver) return;

      const state = gameState.current;
      const width = canvas.width;
      const height = canvas.height;
      const groundY = height - 50;

      // Update Player
      state.player.dy += GRAVITY;
      state.player.y += state.player.dy;

      // Ground collision
      if (state.player.y + state.player.h > groundY) {
        state.player.y = groundY - state.player.h;
        state.player.dy = 0;
        state.player.grounded = true;
      } else {
        state.player.grounded = false;
      }

      // Spawning Obstacles
      state.frame++;
      state.speed += 0.001; // Slowly increase speed

      if (state.frame % Math.floor(1000 / (state.speed * 2)) === 0) {
        const isAir = Math.random() > 0.7;
        state.obstacles.push({
          x: width,
          y: isAir ? groundY - 70 : groundY - 30,
          w: 30,
          h: 30,
          type: isAir ? 'air' : 'ground'
        });
      }

      // Update Obstacles
      for (let i = state.obstacles.length - 1; i >= 0; i--) {
        const obs = state.obstacles[i];
        obs.x -= state.speed;

        // Collision
        if (
          state.player.x < obs.x + obs.w &&
          state.player.x + state.player.w > obs.x &&
          state.player.y < obs.y + obs.h &&
          state.player.y + state.player.h > obs.y
        ) {
          setGameOver(true);
          setHighScore(prev => Math.max(prev, Math.floor(state.frame / 10)));
        }

        // Remove off-screen
        if (obs.x + obs.w < 0) {
          state.obstacles.splice(i, 1);
        }
      }

      // Draw
      ctx.clearRect(0, 0, width, height);
      
      // Ground
      ctx.fillStyle = '#334155';
      ctx.fillRect(0, groundY, width, 50);

      // Player
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(state.player.x, state.player.y, state.player.w, state.player.h);
      // Eye
      ctx.fillStyle = '#fff';
      ctx.fillRect(state.player.x + 20, state.player.y + 5, 5, 5);

      // Obstacles
      ctx.fillStyle = '#f43f5e';
      state.obstacles.forEach(obs => {
        ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
      });

      setScore(Math.floor(state.frame / 10));
      animationId = requestAnimationFrame(update);
    };

    if (isPlaying && !gameOver) {
      animationId = requestAnimationFrame(update);
    }

    return () => cancelAnimationFrame(animationId);
  }, [isPlaying, gameOver]);

  // Handle Controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' || e.code === 'ArrowUp') {
        e.preventDefault();
        if (!isPlaying && !gameOver) setIsPlaying(true);
        else if (gameOver) resetGame();
        else jump();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, gameOver, jump]);

  return (
    <div className="flex flex-col items-center justify-center h-full relative">
      <div className="absolute top-4 left-4 z-10">
        <button onClick={onBack} className="flex items-center gap-2 text-white hover:text-blue-400 transition">
          <ArrowLeft /> Back
        </button>
      </div>
      
      <div className="bg-slate-800 p-2 rounded-xl shadow-2xl relative overflow-hidden">
        <canvas 
          ref={canvasRef} 
          width={800} 
          height={400} 
          className="bg-slate-900 rounded-lg cursor-pointer max-w-full h-auto"
          onClick={() => {
            if (!isPlaying && !gameOver) setIsPlaying(true);
            else if (gameOver) resetGame();
            else jump();
          }}
        />
        
        {/* UI Overlay */}
        <div className="absolute top-4 right-4 flex gap-4 text-white font-pixel">
          <div className="flex items-center gap-2 text-yellow-400">
            <Trophy size={20} /> {highScore}
          </div>
          <div>SCORE: {score}</div>
        </div>

        {(!isPlaying && !gameOver) && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 text-white">
            <h1 className="text-4xl font-pixel mb-4 text-blue-400">PIXEL RUNNER</h1>
            <p className="mb-4 animate-pulse">Press SPACE or TAP to Jump</p>
            <button onClick={() => setIsPlaying(true)} className="bg-blue-500 hover:bg-blue-600 px-6 py-2 rounded-full font-bold flex items-center gap-2">
              <Play size={20} /> START
            </button>
          </div>
        )}

        {gameOver && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 text-white">
            <h2 className="text-3xl font-bold text-red-500 mb-2">GAME OVER</h2>
            <p className="mb-6">Score: {score}</p>
            <button onClick={resetGame} className="bg-white text-black hover:bg-gray-200 px-6 py-2 rounded-full font-bold flex items-center gap-2">
              <RefreshCw size={20} /> TRY AGAIN
            </button>
          </div>
        )}
      </div>
    </div>
  );
}