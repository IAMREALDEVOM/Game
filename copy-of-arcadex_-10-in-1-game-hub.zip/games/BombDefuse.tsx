import React, { useState, useEffect } from 'react';
import { ArrowLeft, RefreshCw, Scissors } from 'lucide-react';

type ModuleType = 'wires' | 'math' | 'code';

export default function BombDefuse({ onBack }: { onBack: () => void }) {
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'won' | 'exploded'>('menu');
  const [timeLeft, setTimeLeft] = useState(10);
  const [module, setModule] = useState<ModuleType>('wires');
  
  // Wires State
  const [wires, setWires] = useState<{color: string, cut: boolean}[]>([]);
  const [correctWireIndex, setCorrectWireIndex] = useState(0);

  // Math State
  const [mathQuestion, setMathQuestion] = useState({ q: '', a: 0 });
  
  // Code State
  const [code, setCode] = useState([0,0,0]);
  const [targetCode, setTargetCode] = useState([0,0,0]);

  const COLORS = ['red', 'blue', 'green', 'yellow', 'white'];

  const startGame = () => {
    setGameState('playing');
    setTimeLeft(15);
    const types: ModuleType[] = ['wires', 'math', 'code'];
    const selected = types[Math.floor(Math.random() * types.length)];
    setModule(selected);

    if (selected === 'wires') {
      const newWires = Array(5).fill(null).map(() => ({
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
        cut: false
      }));
      setWires(newWires);
      setCorrectWireIndex(Math.floor(Math.random() * 5));
    } else if (selected === 'math') {
      const a = Math.floor(Math.random() * 20);
      const b = Math.floor(Math.random() * 20);
      const op = Math.random() > 0.5 ? '+' : '-';
      setMathQuestion({
        q: `${a} ${op} ${b}`,
        a: op === '+' ? a + b : a - b
      });
    } else {
      setTargetCode([
        Math.floor(Math.random() * 9),
        Math.floor(Math.random() * 9),
        Math.floor(Math.random() * 9)
      ]);
      setCode([0,0,0]);
    }
  };

  useEffect(() => {
    if (gameState !== 'playing') return;
    const interval = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 0.1) {
          setGameState('exploded');
          return 0;
        }
        return t - 0.1;
      });
    }, 100);
    return () => clearInterval(interval);
  }, [gameState]);

  const cutWire = (index: number) => {
    if (gameState !== 'playing') return;
    if (index === correctWireIndex) {
      setGameState('won');
    } else {
      setGameState('exploded');
    }
    const newWires = [...wires];
    newWires[index].cut = true;
    setWires(newWires);
  };

  const submitMath = (ans: number) => {
    if (ans === mathQuestion.a) setGameState('won');
    else setGameState('exploded');
  };

  const updateCode = (idx: number) => {
    const newCode = [...code];
    newCode[idx] = (newCode[idx] + 1) % 10;
    setCode(newCode);
    if (newCode[0] === targetCode[0] && newCode[1] === targetCode[1] && newCode[2] === targetCode[2]) {
      setGameState('won');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full relative p-4 bg-gray-900">
      <button onClick={onBack} className="absolute top-4 left-4 text-white hover:text-red-400">
        <ArrowLeft />
      </button>

      {gameState === 'menu' && (
        <div className="text-center text-white">
          <h1 className="text-4xl font-bold mb-4 text-red-500">BOMB DEFUSE</h1>
          <p className="mb-8">Solve the puzzle before time runs out.</p>
          <button onClick={startGame} className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-xl font-bold text-xl">
            START OPERATION
          </button>
        </div>
      )}

      {gameState === 'playing' && (
        <div className="w-full max-w-md bg-gray-800 p-8 rounded-3xl border-4 border-gray-700 shadow-2xl relative">
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-black px-6 py-2 rounded-lg border-2 border-red-900">
            <span className={`font-mono text-3xl font-bold ${timeLeft < 5 ? 'text-red-500 animate-ping' : 'text-red-600'}`}>
              00:{Math.floor(timeLeft).toString().padStart(2, '0')}
            </span>
          </div>

          <div className="mt-8">
            {module === 'wires' && (
              <div className="flex flex-col gap-4">
                <p className="text-slate-400 text-center mb-2">Cut the correct wire!</p>
                {wires.map((wire, i) => (
                  <button 
                    key={i}
                    onClick={() => cutWire(i)}
                    disabled={wire.cut}
                    className={`h-4 w-full rounded-full relative group transition-all ${wire.cut ? 'opacity-30' : 'hover:scale-105'}`}
                    style={{ backgroundColor: wire.color }}
                  >
                    {!wire.cut && <Scissors className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 text-black w-4 h-4" />}
                  </button>
                ))}
              </div>
            )}

            {module === 'math' && (
              <div className="text-center">
                <p className="text-slate-400 mb-4">Solve quickly!</p>
                <div className="text-5xl font-bold text-white mb-8">{mathQuestion.q} = ?</div>
                <div className="grid grid-cols-3 gap-2">
                  {[mathQuestion.a, mathQuestion.a + 1, mathQuestion.a - 2, mathQuestion.a + 5, mathQuestion.a - 3, mathQuestion.a + 10].sort(() => Math.random() - 0.5).map((ans, i) => (
                    <button key={i} onClick={() => submitMath(ans)} className="bg-slate-700 hover:bg-slate-600 text-white p-4 rounded-xl font-bold text-xl">
                      {ans}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {module === 'code' && (
              <div className="text-center">
                <p className="text-slate-400 mb-4">Match the code: <span className="text-green-400 tracking-widest">{targetCode.join('')}</span></p>
                <div className="flex justify-center gap-4">
                  {code.map((digit, i) => (
                    <button 
                      key={i} 
                      onClick={() => updateCode(i)}
                      className="w-16 h-20 bg-black text-green-500 font-mono text-4xl rounded-lg border border-green-900 flex items-center justify-center hover:bg-gray-900"
                    >
                      {digit}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {(gameState === 'won' || gameState === 'exploded') && (
        <div className="text-center animate-bounce-in">
          <div className="text-6xl mb-4">{gameState === 'won' ? '🎉' : '💥'}</div>
          <h2 className={`text-3xl font-bold mb-2 ${gameState === 'won' ? 'text-green-500' : 'text-red-500'}`}>
            {gameState === 'won' ? 'BOMB DEFUSED' : 'EXPLOSION!'}
          </h2>
          <button onClick={startGame} className="mt-8 bg-white text-black px-6 py-2 rounded-full font-bold flex items-center gap-2 mx-auto hover:bg-gray-200">
             <RefreshCw size={20} /> TRY AGAIN
          </button>
        </div>
      )}
    </div>
  );
}