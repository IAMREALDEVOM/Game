import React, { useRef, useEffect, useState } from 'react';
import { ArrowLeft, Skull } from 'lucide-react';

interface Entity {
  x: number;
  y: number;
  angle: number;
}

interface Bullet extends Entity {
  vx: number;
  vy: number;
}

export default function ZombieDefense({ onBack }: { onBack: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [playing, setPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  
  const state = useRef({
    bullets: [] as Bullet[],
    zombies: [] as { x: number, y: number, speed: number }[],
    angle: 0,
    lastShot: 0,
    spawnRate: 1000,
    lastSpawn: 0
  });

  const reset = () => {
    state.current = {
      bullets: [],
      zombies: [],
      angle: 0,
      lastShot: 0,
      spawnRate: 1000,
      lastSpawn: 0
    };
    setScore(0);
    setGameOver(false);
    setPlaying(true);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const cx = width / 2;
    const cy = height / 2;

    let animId: number;

    const loop = (time: number) => {
      if (!playing || gameOver) return;
      
      const s = state.current;

      // Spawn Zombies
      if (time - s.lastSpawn > s.spawnRate) {
        s.lastSpawn = time;
        if (s.spawnRate > 300) s.spawnRate -= 10;
        
        const angle = Math.random() * Math.PI * 2;
        const dist = 500; // spawn outside
        s.zombies.push({
          x: cx + Math.cos(angle) * dist,
          y: cy + Math.sin(angle) * dist,
          speed: 1 + Math.random()
        });
      }

      // Update Bullets
      for (let i = s.bullets.length - 1; i >= 0; i--) {
        const b = s.bullets[i];
        b.x += b.vx;
        b.y += b.vy;
        if (b.x < 0 || b.x > width || b.y < 0 || b.y > height) {
          s.bullets.splice(i, 1);
        }
      }

      // Update Zombies
      for (let i = s.zombies.length - 1; i >= 0; i--) {
        const z = s.zombies[i];
        const dx = cx - z.x;
        const dy = cy - z.y;
        const dist = Math.sqrt(dx*dx + dy*dy);
        
        z.x += (dx / dist) * z.speed;
        z.y += (dy / dist) * z.speed;

        if (dist < 20) {
          setGameOver(true);
        }

        // Bullet Collision
        for (let j = s.bullets.length - 1; j >= 0; j--) {
          const b = s.bullets[j];
          const bdx = b.x - z.x;
          const bdy = b.y - z.y;
          if (Math.sqrt(bdx*bdx + bdy*bdy) < 15) {
            s.bullets.splice(j, 1);
            s.zombies.splice(i, 1);
            setScore(prev => prev + 1);
            break;
          }
        }
      }

      // Draw
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, width, height);

      // Player
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(s.angle);
      ctx.fillStyle = '#38bdf8';
      ctx.beginPath();
      ctx.arc(0, 0, 15, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#fff';
      ctx.fillRect(10, -2, 15, 4); // Gun
      ctx.restore();

      // Bullets
      ctx.fillStyle = '#fbbf24';
      s.bullets.forEach(b => {
        ctx.beginPath();
        ctx.arc(b.x, b.y, 4, 0, Math.PI * 2);
        ctx.fill();
      });

      // Zombies
      ctx.fillStyle = '#22c55e';
      s.zombies.forEach(z => {
        ctx.beginPath();
        ctx.arc(z.x, z.y, 12, 0, Math.PI * 2);
        ctx.fill();
      });

      animId = requestAnimationFrame(loop);
    };

    if (playing) animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [playing, gameOver]);

  // Controls
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left - 400; // cx is 400
      const y = e.clientY - rect.top - 300; // cy is 300
      state.current.angle = Math.atan2(y, x);
    };
    
    const handleClick = () => {
      if (!playing || gameOver) return;
      const s = state.current;
      s.bullets.push({
        x: 400, y: 300, angle: s.angle,
        vx: Math.cos(s.angle) * 10,
        vy: Math.sin(s.angle) * 10
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleClick);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleClick);
    };
  }, [playing, gameOver]);

  return (
    <div className="flex flex-col items-center justify-center h-full relative">
       <button onClick={onBack} className="absolute top-4 left-4 text-white hover:text-green-400 z-10">
        <ArrowLeft />
      </button>

      <div className="relative">
        <canvas 
          ref={canvasRef} 
          width={800} 
          height={600} 
          className="bg-slate-900 rounded-lg cursor-crosshair shadow-2xl max-w-full h-auto"
        />
        
        {(!playing || gameOver) && (
          <div className="absolute inset-0 bg-black/70 flex items-center justify-center flex-col text-white">
            <h1 className="text-4xl font-bold mb-2 text-green-500 font-pixel">ZOMBIE DEFENSE</h1>
            <p className="mb-6">Score: {score}</p>
            <button onClick={reset} className="bg-red-600 hover:bg-red-700 px-8 py-3 rounded-full font-bold flex items-center gap-2">
              <Skull /> {gameOver ? 'TRY AGAIN' : 'START SURVIVAL'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}